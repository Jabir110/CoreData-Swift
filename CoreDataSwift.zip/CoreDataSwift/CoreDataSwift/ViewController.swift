//
//  ViewController.swift
//  CoreDataSwift
//
//  Created by mackbook on 4/5/16.
//  Copyright © 2017 VirtualHeight. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController {

    var rollArry = [Any]()
    var passwordArry = [Any]()
    
    @IBOutlet var txtRollNumber: UITextField!
    @IBOutlet var txtName: UITextField!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        let appdelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appdelegate.persistentContainer.viewContext
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "User")
        request.returnsObjectsAsFaults = false
        
        do
        {
            let results = try context.fetch(request)
            
            if results.count > 0
            {
                for result in results
                {
                    if let username = (result as AnyObject).value(forKey: "rollNo") as? String
                    {
                        rollArry.append(username)
                    }
                    if let password = (result as AnyObject).value(forKey: "name") as? String
                    {
                        passwordArry.append(password)
                    }
                }
                print(rollArry)
                print(passwordArry)
            }
        }
        catch
        {
            
        }

        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func StoreData()
    {
        let appdelegate = (UIApplication.shared.delegate) as! AppDelegate
        let context = appdelegate.persistentContainer.viewContext
        //store data & intialize Entity
        let newuser = NSEntityDescription.insertNewObject(forEntityName: "User", into: context)
        //Setting value of data
        newuser.setValue(txtRollNumber.text, forKey: "rollNo")
        newuser.setValue(txtName.text, forKey: "name")
        do
        {
            try context.save()
            print("Saved")
        }
        catch
        {
            print("Error")
        }
    }
    
    @IBAction func ActionSave(_ sender: Any)
    {
        self.StoreData();
    }
    
}

